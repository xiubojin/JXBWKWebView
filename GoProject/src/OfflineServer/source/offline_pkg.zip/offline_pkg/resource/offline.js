function getMapAuthState() {
        window.JXBJSBridge.call({
                               target : "location",
                               action : "getAuthorityState",
                               data : {},
                               callback : {
                               success : function(result){document.getElementById('message').innerHTML = result;},
                               fail : function(result){document.getElementById('message').innerHTML = result;},
                               progress : function(result){document.getElementById('message').innerHTML = result;},
                               }
                               });
    }

function getMapAuthority() {
    window.JXBJSBridge.call({
                           target : "location",
                           action : "getAuthority",
                           data : {"type":"2"},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}

function openSystemMapPage() {
    window.JXBJSBridge.call({
                           target : "location",
                           action : "openSystemLocationPage",
                           data : {},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}
    
    function getCacheSize() {
        window.JXBJSBridge.call({
                               target : "setting",
                               action : "getCacheSize",
                               data : {},
                               callback : {
                               success : function(result){document.getElementById('message').innerHTML = result;},
                               fail : function(result){document.getElementById('message').innerHTML = result;},
                               progress : function(result){document.getElementById('message').innerHTML = result;},
                               }
                               });
    }

function clearCache() {
    window.JXBJSBridge.call({
                           target : "setting",
                           action : "clearCache",
                           data : {},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}

function getPushAuthState() {
    window.JXBJSBridge.call({
                           target : "push",
                           action : "getAuthorityState",
                           data : {},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}

function getAuthority() {
    window.JXBJSBridge.call({
                           target : "push",
                           action : "getAuthority",
                           data : {},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}

function openSystemNotifiPage() {
    window.JXBJSBridge.call({
                           target : "push",
                           action : "openSystemNotifiPage",
                           data : {},
                           callback : {
                           success : function(result){document.getElementById('message').innerHTML = result;},
                           fail : function(result){document.getElementById('message').innerHTML = result;},
                           progress : function(result){document.getElementById('message').innerHTML = result;},
                           }
                           });
}